/* Golden reference deck — exercises every component in deck-components.js.
   Content is deliberately generic. Copy this file as the starting point for a
   real lesson and replace the content only. */

const C = require('./assets/deck-components.js');

(async () => {
  const pres = C.newDeck({ title: 'EduPortal lesson template' });

  /* 1 — cover */
  C.notes(C.cover(pres, {
    eyebrow: 'UNIT [N] \u00B7 [AREA OF STUDY] \u00B7 [SUBJECT] \u00B7 LESSON [N]',
    title: 'Lesson title goes here',
    subtitle: 'Sub-idea one \u00B7 Sub-idea two \u00B7 Sub-idea three \u00B7 Sub-idea four',
    leftLines: [
      { text: 'Year [N] [Subject]', bold: true },
      { text: 'Double period \u00B7 100 minutes' },
      { text: 'Case context: [organisation]' }
    ],
    rightLines: [
      { text: 'Last lesson: [prior topic]' },
      { text: 'Today: [today\u2019s claim]', bold: true },
      { text: 'Notebooks out \u2014 laptops stay shut' }
    ]
  }), 'Cover. Do not read it aloud — students are settling. Names and date go in the workbook, not here. Have the case context visible before the warm up starts.');

  /* 2 — warm up */
  let s = C.slide(pres, {
    stage: 'WARM UP', device: 'NO TECH',
    title: 'Warm up \u2014 [hook question]',
    subtitle: '5 minutes \u00B7 in pairs \u00B7 notebooks only'
  });
  C.callout(s, 'One sentence framing the task. What are students sorting, judging or guessing?', 'info');
  C.letteredList(s, [
    'Warm-up item one \u2014 short enough to read from the back of the room.',
    'Warm-up item two.',
    'Warm-up item three.',
    'Warm-up item four.',
    'Warm-up item five.'
  ], { reserve: C.CALLOUT_H });
  C.callout(s, 'Then: what separates the good ones from the rest?', 'note');
  C.notes(s, 'Timing: 5 min. Do not resolve it — the answer comes out of the explicit teaching. Circulate and note which pairs are reasoning rather than guessing; call on those first.');

  /* 3 — objective */
  s = C.slide(pres, {
    stage: 'OBJECTIVE', device: 'NO TECH',
    title: 'Learning objective'
  });
  C.callout(s, 'To be able to [verb] [object] [condition] \u2014 concise, one sentence, copyable.', 'info', 1.25);
  C.sectionHeading(s, 'Success criteria', 2.35);
  C.tierCards(s,
    { primary: 'I can [recall or explain the core idea].', secondary: 'I can tell a good example from a poor one.' },
    { primary: 'I can [produce the thing] for a given context.', secondary: 'I can apply it to evidence and justify a judgement.' },
    { primary: 'I can [evaluate or critique] a worked set.', secondary: 'I can weigh two competing considerations.' },
    { y: 2.90, h: 3.30 });
  C.footer(s, 'You will self-assess against these criteria on the exit ticket.');
  C.notes(s, 'Read the objective aloud once, then have students copy it. Point at the tier they are aiming for. Return to this slide at the check-in.');

  /* 4 — retrieval */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: 'Retrieval \u2014 [last lesson\u2019s topic]',
    subtitle: 'Cold call \u00B7 no notes \u00B7 3 minutes'
  });
  C.numberedList(s, [
    'Retrieval question one.',
    'Retrieval question two.',
    'Retrieval question three.',
    'Retrieval question four.'
  ]);
  C.notes(s, 'Cold call, no hands. If two students in a row cannot answer, reteach it in 60 seconds rather than pushing on — today builds directly on this.');

  /* 5 — explicit teaching with copy marker */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: '[Key concept]',
    subtitle: 'Four reasons this matters'
  });
  C.copyBanner(s);
  C.numberedList(s, [
    { head: 'Reason one', body: 'One line of explanation, written for the back row.' },
    { head: 'Reason two', body: 'One line of explanation.' },
    { head: 'Reason three', body: 'One line of explanation.' },
    { head: 'Reason four', body: 'One line of explanation.' }
  ]);
  C.notes(s, 'This is the copy-down slide. Give 3 minutes of silence. Do not talk over students while they write.');

  /* 6 — worked example */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: 'Worked example',
    subtitle: '[context] \u00B7 model the method once, out loud'
  });
  C.comparePair(s,
    { label: 'ATTEMPT 1 \u2014 DOESN\u2019T WORK', text: 'The weak version. State plainly why it fails: what can\u2019t be done with it?' },
    { label: 'ATTEMPT 2 \u2014 WORKS', text: 'The strong version. Name the specific property that fixed it.' },
    { y: 1.45, h: 2.10 });
  C.dataTable(s,
    ['Part', 'What it does', 'From the example above'],
    [
      ['Part one', 'Its job in one phrase', 'The corresponding piece'],
      ['Part two', 'Its job in one phrase', 'The corresponding piece'],
      ['Part three', 'Its job in one phrase', 'The corresponding piece']
    ],
    { y: 3.90, colW: [3.0, 4.4, 4.83], rowH: 0.52 });
  C.notes(s, 'Think aloud through attempt 1 before revealing attempt 2 — the failure is the teaching. Only one worked example here; the practice volume lives in the workbook.');

  /* 7 — discussion */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: 'Discussion \u2014 [tension to surface]',
    subtitle: '8 minutes \u00B7 groups of three'
  });
  C.callout(s, 'One sentence naming the tension. There should be no single right answer here.', 'info');
  C.numberedList(s, [
    'Discussion prompt one.',
    'Discussion prompt two.',
    'Discussion prompt three.'
  ], { reserve: C.CALLOUT_H });
  C.callout(s, 'Extending: argue the opposite case and say what it would cost.', 'extend');
  C.notes(s, 'Groups of three, 8 min. Take two contrasting responses only — resist doing a full round of the room, it eats the applying block.');

  /* 8 — brain break */
  C.notes(C.brainBreak(pres, {
    text: 'Two minutes. Stand up, stretch, look out the window.',
    next: 'Coming up: [next segment] \u2014 then laptops open.'
  }), 'Genuine break. Do not use it to set up the next activity. Two minutes, timed.');

  /* 9 — misconceptions */
  s = C.slide(pres, {
    stage: 'REFLECTING', device: 'NO TECH',
    title: 'Three things that go wrong here',
    subtitle: 'Check your own work against each'
  });
  C.numberedList(s, [
    { head: 'Misconception one', body: 'What it looks like, and the one-line correction.' },
    { head: 'Misconception two', body: 'What it looks like, and the one-line correction.' },
    { head: 'Misconception three', body: 'What it looks like, and the one-line correction.' }
  ], { rowH: 1.10 });
  C.notes(s, 'These are the three errors that actually appear in student work. Ask for a show of hands on which one they think they are most at risk of.');

  /* 10 — laptop gate */
  C.notes(C.laptopGate(pres, {
    title: 'Laptop gate \u2014 open your workbook',
    file: 'L[N]_[ShortTitle]_workbook.html',
    sections: '1\u20137',
    minutes: 30,
    instruction: 'Laptops open now. Your paper notes stay open beside you \u2014 you will need them.',
    tasks: [
      { head: 'Sections 1\u20133 \u2014 everyone', body: 'Foundation. Auto-marked, so you get feedback immediately.' },
      { head: 'Sections 4\u20135 \u2014 everyone', body: 'Developing. Written responses, saved as you type.' },
      { head: 'Section 6 \u2014 if you finish early', body: 'Extending. Attempt it only once 1\u20135 are complete.' }
    ]
  }), 'The only slide where devices come out. Do the gate explicitly: lids stay shut until this slide is up. Circulate rather than sitting at the desk — 30 minutes.');

  /* 11 — check in */
  s = C.slide(pres, {
    stage: 'REFLECTING', device: 'DEVICES',
    title: 'Check in \u2014 where should you be?',
    subtitle: '10 minutes before the exit ticket'
  });
  C.dataTable(s,
    ['Success criterion', 'You are on track if\u2026', 'Stuck? Try this'],
    [
      ['Foundation criterion', 'What a met response looks like', 'The specific redirect'],
      ['Developing criterion', 'What a met response looks like', 'The specific redirect'],
      ['Extending criterion', 'What a met response looks like', 'The specific redirect']
    ],
    { y: 1.60, colW: [3.6, 4.6, 4.03], rowH: 0.62 });
  C.callout(s, 'Assessment: you should now be able to complete [section] of the unit assessment.', 'note', 4.30);
  C.notes(s, 'Formative, not graded. Ask students to self-rate against the tier they aimed for on the objective slide, then compare with the middle column.');

  /* 12 — exit ticket */
  C.notes(C.exitTicket(pres, {
    location: 'Workbook Section 7',
    minutes: 5,
    device: 'DEVICES',
    questions: [
      'Exit question one \u2014 recall.',
      'Exit question two \u2014 application.',
      'Exit question three \u2014 self-assessment against the criteria.'
    ],
    closing: 'Submit before you pack up. No notes.'
  }), 'Five minutes, notes closed. Submission writes the progress status — students who do not submit will show as in-progress on the dashboard.');

  /* 13 — next steps */
  s = C.slide(pres, {
    stage: 'NEXT STEPS', device: 'DEVICES',
    title: 'Next steps'
  });
  C.numberedList(s, [
    { head: 'Next lesson \u2014 L[N+1]: [title]', body: 'One line on what it covers and how it follows from today.' },
    { head: 'Assessment progress', body: 'Where you should be on the unit assessment by now.' },
    { head: 'Homework', body: 'What to finish, and by when (YYYY-MM-DD).' },
    { head: 'Stuck?', body: 'Unit site for full notes; ask before the next lesson, not during it.' }
  ], { y: 1.45, rowH: 1.15 });
  C.notes(s, 'Say the due date aloud and have students write it. Point at the unit site link — it is the reference, the workbook is not.');

  await pres.writeFile({ fileName: 'TEMPLATE_lesson.pptx' });
  console.log('wrote TEMPLATE_lesson.pptx');
})();
