# EduPortal lesson template

Freezes the design decisions that were drifting between lessons. The rule the
whole bundle enforces: **a lesson generator supplies content, never design values.**

## What's here

| File | Role |
|---|---|
| `assets/tokens.json` | Single source of truth — colours, fonts, type scale, geometry, storage keys |
| `assets/deck-components.js` | pptxgenjs component library. Owns all slide geometry and type sizes |
| `assets/eduportal.css` | Shared stylesheet. Inline verbatim into both the workbook and the unit site |
| `assets/validate.py` | Conformance gate. Run before presenting any lesson files |
| `TEMPLATE_lesson.pptx` | Golden deck — 13 slides, every component rendered |
| `TEMPLATE_workbook.html` | Golden workbook — 6 activity archetypes, full DataService engine |
| `build-template-deck.js` | Source of the golden deck. **Copy this to start a new lesson** |

## Making a lesson

```bash
cp build-template-deck.js build-L7.js     # then replace content only
node build-L7.js
python3 assets/validate.py L7_Thing.pptx L7_Thing_workbook.html
```

If validate.py reports a problem, fix it in the generator — never by hand-editing
the output, because the hand edit is exactly how drift re-enters.

## What changed from the L6 lesson

**Fonts.** Verdana (display) / Arial (body) replaces Bookman Old Style / Calibri /
Courier New. Both new faces are British Dyslexia Association recommendations and
ship with Office on every platform. Mono is retired from student-facing text — it
now appears only in the workbook's `.evidence` block, where the content genuinely
is data. Chip labels moved from all-caps Courier to Arial Bold with letter-spacing.
The workbook drops DM Serif Display and DM Sans for Atkinson Hyperlegible
throughout; hierarchy comes from weight and size rather than from a serif face.

**Stage chips are neutral.** All eight stages render in `#5B6472` except EXIT,
which stays red. Green, amber and purple now mean tier and nothing else.

**Device chip moved to blue.** `LAPTOPS` was green, colliding with the Foundation
tier. It is now `DEVICES` in blue — blue already carries "interactive" everywhere
else in the system.

**Type scale is eight sizes.** L6 used 22 distinct sizes between 8.5pt and 44pt.
Anything outside `coverTitle 40 / slideTitle 30 / lead 22 / body 20 / bodySm 18 /
card 16 / caption 12 / chip 11` now fails validation. The old 8.5pt and 9pt badge
text was below the readable floor for a projected classroom slide.

**Neutrals unified on the deck's values** — `#F4F6FB` surface, `#D8DDE6` border.
The workbook's light theme changed to match; dark mode is untouched.

## Adding something new

If a lesson needs a colour, size or component that isn't here, add it to
`tokens.json` first, expose it as a function in `deck-components.js` or a class in
`eduportal.css`, then use it. That keeps the next lesson's options identical to
this one's, which is the entire point.
