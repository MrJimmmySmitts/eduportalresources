/* =============================================================
   EduPortal — deck component library
   -------------------------------------------------------------
   Every lesson deck is assembled from these functions. They own
   the geometry, the type sizes and the colours; a lesson script
   supplies content only.

   RULE: a lesson generator must never write a literal hex colour,
   font name, pt size or inch coordinate. If you need one that
   isn't here, add it to tokens.json and expose it as a component.

   Usage:
     const C = require('./deck-components.js');
     const pres = C.newDeck();
     const s = C.slide(pres, { stage: 'LEARNING', device: 'NO TECH',
                               title: '...', subtitle: '...' });
     C.numberedList(s, [...]);
     C.footer(s, '...');
     C.notes(s, '...');
     await pres.writeFile({ fileName: 'L1_Thing.pptx' });
   ============================================================= */

const pptxgen = require('pptxgenjs');
const T = require('./tokens.json');

const C = T.colour, G = T.geometry, F = T.font.deck, S = T.typeScale;

/* ---------- internal helpers ---------- */

// Resolve a semantic name ('foundation', 'stageChip') or a raw token
// name ('blue', 'muted') to a hex string. Never returns a '#'.
function col(name) {
  if (T.semantics[name]) name = T.semantics[name];
  if (!C[name]) throw new Error(`Unknown colour token: ${name}`);
  return C[name];
}

function tierToken(tier) {
  const map = { foundation: 'green', developing: 'amber', extending: 'purple', assessed: 'red' };
  const k = String(tier).toLowerCase();
  if (!map[k]) throw new Error(`Unknown tier: ${tier}. Use foundation | developing | extending | assessed.`);
  return map[k];
}
function tint(token) {
  const map = { blue: 'blueTint', green: 'greenTint', amber: 'amberTint', purple: 'purpleTint', red: 'redTint' };
  return C[map[token]] || C.surface;
}

// pptxgenjs mutates option objects in place — always build fresh.
function box(o) { return Object.assign({ margin: 0 }, o); }

/* ---------- deck ---------- */

function newDeck(meta = {}) {
  const pres = new pptxgen();
  pres.layout = 'LAYOUT_WIDE';              // 13.333 x 7.5 — set BEFORE any slide
  pres.author = meta.author || 'EduPortal';
  pres.title = meta.title || 'Lesson';
  return pres;
}

/* ---------- chrome: every slide gets this ---------- */

function stageChip(s, stage) {
  if (!T.stages[stage]) throw new Error(`Unknown stage: ${stage}. One of: ${Object.keys(T.stages).join(', ')}`);
  const fill = col(T.stages[stage]);
  const x = G.slideW - G.marginX - G.deviceChipW - G.gap - G.stageChipW;
  s.addShape('roundRect', box({ x, y: G.chipY, w: G.stageChipW, h: G.chipH,
    fill: { color: fill }, line: { color: fill }, rectRadius: 0.16 }));
  s.addText(stage, box({ x, y: G.chipY, w: G.stageChipW, h: G.chipH,
    fontFace: F.body, fontSize: S.chip, bold: true, charSpacing: 1.2,
    color: C.base, align: 'center', valign: 'middle' }));
}

function deviceChip(s, device) {
  const d = T.device[device];
  if (!d) throw new Error(`Unknown device state: ${device}. Use 'NO TECH' or 'DEVICES'.`);
  const x = G.slideW - G.marginX - G.deviceChipW;
  s.addShape('roundRect', box({ x, y: G.chipY, w: G.deviceChipW, h: G.chipH,
    fill: { color: col(d.fill) }, line: { color: col(d.line), width: 1 }, rectRadius: 0.16 }));
  s.addText(device, box({ x, y: G.chipY, w: G.deviceChipW, h: G.chipH,
    fontFace: F.body, fontSize: S.chip, bold: true, charSpacing: 1.0,
    color: col(d.text), align: 'center', valign: 'middle' }));
}

/**
 * Create a content slide with its full chrome.
 * opts: { stage, device, title, subtitle }
 */
function slide(pres, opts) {
  const s = pres.addSlide();
  s.background = { color: C.base };
  stageChip(s, opts.stage);
  deviceChip(s, opts.device);
  if (opts.title) {
    s.addText(opts.title, box({ x: G.marginX, y: G.titleY, w: G.titleW, h: G.titleH,
      fontFace: F.display, fontSize: S.slideTitle, bold: true, color: C.ink, valign: 'middle' }));
  }
  if (opts.subtitle) {
    s.addText(opts.subtitle, box({ x: G.marginX, y: G.subtitleY, w: G.contentW, h: G.subtitleH,
      fontFace: F.body, fontSize: S.caption, color: C.muted, valign: 'middle' }));
  }
  s._cursor = opts.subtitle ? G.contentTop : G.contentTop - 0.20;
  return s;
}

/* ---------- cover ---------- */

/**
 * opts: { eyebrow, title, subtitle, leftLines[], rightLines[] }
 * leftLines/rightLines: [{ text, bold }]
 */
function cover(pres, opts) {
  const s = pres.addSlide();
  s.background = { color: C.base };
  s.addShape('roundRect', box({ x: G.marginX, y: 0.70, w: G.contentW, h: 6.10,
    fill: { color: C.surface }, line: { color: C.border }, rectRadius: 0.16 }));

  const ix = G.marginX + 0.55, iw = G.contentW - 1.10;
  s.addText(opts.eyebrow, box({ x: ix, y: 1.50, w: iw, h: 0.40,
    fontFace: F.body, fontSize: S.caption, bold: true, charSpacing: 1.4, color: C.blue, valign: 'middle' }));
  s.addText(opts.title, box({ x: ix, y: 2.00, w: iw, h: 1.25,
    fontFace: F.display, fontSize: S.coverTitle, bold: true, color: C.ink, valign: 'top' }));
  if (opts.subtitle) {
    s.addText(opts.subtitle, box({ x: ix, y: 3.35, w: iw, h: 0.70,
      fontFace: F.body, fontSize: S.bodySm, color: C.muted, valign: 'top' }));
  }

  const panelW = (iw - 0.35) / 2;
  [[opts.leftLines, ix], [opts.rightLines, ix + panelW + 0.35]].forEach(([lines, x]) => {
    if (!lines || !lines.length) return;
    s.addShape('roundRect', box({ x, y: 4.55, w: panelW, h: 1.55,
      fill: { color: C.base }, line: { color: C.border }, rectRadius: 0.14 }));
    s.addText(lines.map((l, i) => ({
      text: l.text,
      options: { bold: !!l.bold, breakLine: i < lines.length - 1 }
    })), box({ x: x + 0.25, y: 4.72, w: panelW - 0.50, h: 1.24,
      fontFace: F.body, fontSize: S.card, color: C.ink, lineSpacingMultiple: 1.25, valign: 'top' }));
  });
  return s;
}

/* ---------- content components ---------- */

/** Full-width tinted band. kind: info | tip | note | extend | exit */
function callout(s, text, kind = 'info', y = null) {
  const map = { info: 'blue', tip: 'green', note: 'amber', extend: 'purple', exit: 'red' };
  const tok = map[kind];
  if (!tok) throw new Error(`Unknown callout kind: ${kind}`);
  const top = y === null ? s._cursor : y;
  const h = 0.80;
  s.addShape('roundRect', box({ x: G.marginX, y: top, w: G.contentW, h,
    fill: { color: tint(tok) }, line: { color: C[tok] }, rectRadius: 0.14 }));
  s.addText(text, box({ x: G.marginX + 0.30, y: top, w: G.contentW - 0.60, h,
    fontFace: F.body, fontSize: S.bodySm, color: C.ink, valign: 'middle' }));
  s._cursor = top + h + G.gap;
  return s;
}

/** The "write this down" marker. Sits inline, amber. */
function copyBanner(s, text = 'Copy this into your notes', y = null) {
  const top = y === null ? s._cursor : y;
  const h = 0.42, w = 3.55;
  s.addShape('roundRect', box({ x: G.marginX, y: top, w, h,
    fill: { color: C.amberTint }, line: { color: C.amber }, rectRadius: 0.14 }));
  s.addText('\u270E  ' + text, box({ x: G.marginX + 0.20, y: top, w: w - 0.40, h,
    fontFace: F.body, fontSize: S.caption, bold: true, color: C.ink, valign: 'middle' }));
  s._cursor = top + h + G.gap;
  return s;
}

/** Numbered rows. items: [{ head, body }] or [string] */
function numberedList(s, items, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const avail = G.contentBottom - top - (opts.reserve || 0);
  const h = Math.min(opts.rowH || 0.84, (avail - G.gap * (items.length - 1)) / items.length);
  items.forEach((it, i) => {
    const y = top + i * (h + G.gap);
    const head = typeof it === 'string' ? null : it.head;
    const body = typeof it === 'string' ? it : it.body;
    s.addShape('roundRect', box({ x: G.marginX, y, w: G.contentW, h,
      fill: { color: C.base }, line: { color: C.border }, rectRadius: 0.12 }));
    const d = 0.44, dy = y + (h - d) / 2;
    s.addShape('ellipse', box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fill: { color: C.surface }, line: { color: C.border } }));
    s.addText(String(i + 1), box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fontFace: F.body, fontSize: S.caption, bold: true, color: C.muted,
      align: 'center', valign: 'middle' }));
    const tx = G.marginX + 0.80, tw = G.contentW - 1.05;
    if (head) {
      s.addText([
        { text: head, options: { bold: true, breakLine: true } },
        { text: body, options: { fontSize: S.card, color: C.muted } }
      ], box({ x: tx, y, w: tw, h, fontFace: F.body, fontSize: S.bodySm, color: C.ink, valign: 'middle' }));
    } else {
      s.addText(body, box({ x: tx, y, w: tw, h,
        fontFace: F.body, fontSize: S.body, color: C.ink, valign: 'middle' }));
    }
  });
  s._cursor = top + items.length * (h + G.gap);
  return s;
}

/** Lettered rows (A/B/C) — for sorting and spot-the-error warm-ups. */
function letteredList(s, items, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const avail = G.contentBottom - top - (opts.reserve || 0);
  const h = Math.min(opts.rowH || 0.72, (avail - G.gap * (items.length - 1)) / items.length);
  items.forEach((text, i) => {
    const y = top + i * (h + G.gap);
    s.addShape('roundRect', box({ x: G.marginX, y, w: G.contentW, h,
      fill: { color: C.base }, line: { color: C.border }, rectRadius: 0.12 }));
    const d = 0.42, dy = y + (h - d) / 2;
    s.addShape('roundRect', box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fill: { color: C.surface }, line: { color: C.border }, rectRadius: 0.10 }));
    s.addText(String.fromCharCode(65 + i), box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fontFace: F.body, fontSize: S.caption, bold: true, color: C.muted,
      align: 'center', valign: 'middle' }));
    s.addText(text, box({ x: G.marginX + 0.80, y, w: G.contentW - 1.05, h,
      fontFace: F.body, fontSize: S.body, color: C.ink, valign: 'middle' }));
  });
  s._cursor = top + items.length * (h + G.gap);
  return s;
}

/** Three tier cards. Each: { primary, secondary }. Colour comes from the tier, always. */
function tierCards(s, f, d, e, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const h = opts.h || 3.30;
  const w = (G.contentW - G.gap * 2) / 3;
  [['Foundation', f, 'foundation'], ['Developing', d, 'developing'], ['Extending', e, 'extending']]
    .forEach(([label, content, tier], i) => {
      const tok = tierToken(tier);
      const x = G.marginX + i * (w + G.gap);
      s.addShape('roundRect', box({ x, y: top, w, h,
        fill: { color: C.base }, line: { color: C[tok], width: 1.5 }, rectRadius: 0.14 }));
      const lw = 1.60, lh = 0.32;
      s.addShape('roundRect', box({ x: x + 0.25, y: top + 0.22, w: lw, h: lh,
        fill: { color: C[tok] }, line: { color: C[tok] }, rectRadius: 0.14 }));
      s.addText(label.toUpperCase(), box({ x: x + 0.25, y: top + 0.22, w: lw, h: lh,
        fontFace: F.body, fontSize: S.chip, bold: true, charSpacing: 1.0,
        color: C.base, align: 'center', valign: 'middle' }));
      s.addText(content.primary, box({ x: x + 0.25, y: top + 0.72, w: w - 0.50, h: 1.45,
        fontFace: F.body, fontSize: S.card, color: C.ink, valign: 'top' }));
      if (content.secondary) {
        s.addShape('line', box({ x: x + 0.25, y: top + 2.25, w: w - 0.50, h: 0,
          line: { color: C.border, width: 1 } }));
        s.addText(content.secondary, box({ x: x + 0.25, y: top + 2.38, w: w - 0.50, h: h - 2.60,
          fontFace: F.body, fontSize: S.card, color: C.muted, valign: 'top' }));
      }
    });
  s._cursor = top + h + G.gap;
  return s;
}

/** Data table. headers: [string], rows: [[string]], colW: [inches] optional */
function dataTable(s, headers, rows, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const colW = opts.colW || headers.map(() => G.contentW / headers.length);
  s.addTable([
    headers.map(h => ({ text: h, options: {
      bold: true, color: C.muted, fill: { color: C.surface }, fontSize: S.caption } })),
    ...rows.map(r => r.map(c => ({ text: c, options: { color: C.ink, fontSize: S.card } })))
  ], {
    x: G.marginX, y: top, w: G.contentW, colW,
    border: { type: 'solid', color: C.border, pt: 1 },
    fontFace: F.body, valign: 'top', autoPage: false,
    margin: 0.08
  });
  s._cursor = top + 0.42 + rows.length * (opts.rowH || 0.52);
  return s;
}

/** Before/after or wrong/right pair. */
function comparePair(s, left, right, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const h = opts.h || 2.10;
  const w = (G.contentW - G.gap) / 2;
  [[left, 'red', G.marginX], [right, 'green', G.marginX + w + G.gap]].forEach(([side, tok, x]) => {
    s.addShape('roundRect', box({ x, y: top, w, h,
      fill: { color: tint(tok) }, line: { color: C[tok] }, rectRadius: 0.14 }));
    s.addText(side.label, box({ x: x + 0.25, y: top + 0.18, w: w - 0.50, h: 0.34,
      fontFace: F.body, fontSize: S.caption, bold: true, charSpacing: 1.0, color: C[tok], valign: 'middle' }));
    s.addText(side.text, box({ x: x + 0.25, y: top + 0.60, w: w - 0.50, h: h - 0.85,
      fontFace: F.body, fontSize: S.bodySm, color: C.ink, valign: 'top' }));
  });
  s._cursor = top + h + G.gap;
  return s;
}

/** The laptop gate — the one slide where devices come out. */
function laptopGate(pres, opts) {
  const s = slide(pres, {
    stage: 'APPLYING', device: 'DEVICES',
    title: opts.title || 'Open your workbook',
    subtitle: `${opts.file} \u00B7 Sections ${opts.sections} \u00B7 ${opts.minutes} minutes`
  });
  callout(s, opts.instruction, 'tip');
  if (opts.tasks) numberedList(s, opts.tasks);
  return s;
}

/** Exit ticket. questions: [string] */
function exitTicket(pres, opts) {
  const s = slide(pres, {
    stage: 'EXIT', device: opts.device || 'DEVICES',
    title: 'Exit ticket',
    subtitle: `${opts.location} \u00B7 ${opts.minutes} minutes \u00B7 no notes`
  });
  numberedList(s, opts.questions, { rowH: 0.78 });
  callout(s, opts.closing || 'Submit before you pack up.', 'exit', G.contentBottom - 0.80);
  return s;
}

/** Brain break. */
function brainBreak(pres, opts = {}) {
  const s = slide(pres, { stage: 'BREAK', device: 'NO TECH', title: 'Brain break' });
  s.addShape('roundRect', box({ x: G.marginX, y: 2.10, w: G.contentW, h: 2.60,
    fill: { color: C.surface }, line: { color: C.border }, rectRadius: 0.16 }));
  s.addText(opts.text || 'Two minutes. Stand up, stretch, look out the window.',
    box({ x: G.marginX + 0.60, y: 2.55, w: G.contentW - 1.20, h: 0.80,
      fontFace: F.display, fontSize: S.lead, bold: true, color: C.ink, align: 'center', valign: 'middle' }));
  s.addText(opts.next || '', box({ x: G.marginX + 0.60, y: 3.50, w: G.contentW - 1.20, h: 0.70,
    fontFace: F.body, fontSize: S.bodySm, color: C.muted, align: 'center', valign: 'top' }));
  return s;
}

/** In-slide heading, for splitting a slide into two labelled halves. */
function sectionHeading(s, text, y = null) {
  const top = y === null ? s._cursor : y;
  s.addText(text, box({ x: G.marginX, y: top, w: G.contentW, h: 0.40,
    fontFace: F.display, fontSize: S.lead, bold: true, color: C.ink, valign: 'middle' }));
  s._cursor = top + 0.40 + G.gap;
  return s;
}

/** Height a callout occupies — pass as `reserve` when one follows a list. */
const CALLOUT_H = 1.14;

/** Footer note, pinned to the baseline. */
function footer(s, text) {
  s.addText(text, box({ x: G.marginX, y: G.footerY, w: G.contentW, h: G.footerH,
    fontFace: F.body, fontSize: S.caption, color: C.muted, valign: 'middle' }));
  return s;
}

/** Speaker notes — required on every slide. */
function notes(s, text) { s.addNotes(text); return s; }

module.exports = {
  tokens: T, newDeck, cover, slide, stageChip, deviceChip,
  callout, copyBanner, numberedList, letteredList, tierCards, dataTable,
  comparePair, laptopGate, exitTicket, brainBreak, sectionHeading, footer, notes, CALLOUT_H
};
