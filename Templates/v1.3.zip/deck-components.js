/* =============================================================
   EduPortal — deck component library
   -------------------------------------------------------------
   Every lesson deck is assembled from these functions. They own
   the geometry, the type sizes and the colours; a lesson script
   supplies content only.

   RULE: a lesson generator must never write a literal hex colour,
   font name, pt size or inch coordinate. If you need one that
   isn't here, add it to tokens.json and expose it as a component.

   Usage:
     const C = require('./deck-components.js');
     const pres = C.newDeck();
     const s = C.slide(pres, { stage: 'LEARNING', device: 'NO TECH',
                               title: '...', subtitle: '...' });
     C.numberedList(s, [...]);
     C.footer(s, '...');
     C.notes(s, '...');
     await pres.writeFile({ fileName: 'L1_Thing.pptx' });
   ============================================================= */

const pptxgen = require('pptxgenjs');
const T = require('./tokens.json');

const C = T.colour, G = T.geometry, F = T.font.deck, S = T.typeScale;

/* ---------- internal helpers ---------- */

// Resolve a semantic name ('foundation', 'stageChip') or a raw token
// name ('blue', 'muted') to a hex string. Never returns a '#'.
function col(name) {
  if (T.semantics[name]) name = T.semantics[name];
  if (!C[name]) throw new Error(`Unknown colour token: ${name}`);
  return C[name];
}

function tierToken(tier) {
  const map = { foundation: 'green', developing: 'amber', extending: 'purple', assessed: 'red' };
  const k = String(tier).toLowerCase();
  if (!map[k]) throw new Error(`Unknown tier: ${tier}. Use foundation | developing | extending | assessed.`);
  return map[k];
}
function tint(token) {
  const map = { blue: 'blueTint', green: 'greenTint', amber: 'amberTint', purple: 'purpleTint', red: 'redTint' };
  return C[map[token]] || C.surface;
}

// pptxgenjs mutates option objects in place — always build fresh.
function box(o) { return Object.assign({ margin: 0 }, o); }

// Depth. Always returns a NEW object — never share one across two add* calls.
function sh(level = 'card') {
  const d = T.depth[level];
  return { type: 'outer', blur: d.blur, offset: d.offset, angle: d.angle,
           color: d.color, opacity: d.opacity };
}

/* ---------- deck ---------- */

function newDeck(meta = {}) {
  const pres = new pptxgen();
  pres.layout = 'LAYOUT_WIDE';              // 13.333 x 7.5 — set BEFORE any slide
  pres.author = meta.author || 'EduPortal';
  pres.title = meta.title || 'Lesson';
  return pres;
}

/* ---------- chrome: every slide gets this ---------- */

function stageChip(s, stage) {
  if (!T.stages[stage]) throw new Error(`Unknown stage: ${stage}. One of: ${Object.keys(T.stages).join(', ')}`);
  const accent = col(T.stages[stage]);
  const x = G.slideW - G.marginX - G.deviceChipW - G.gap - G.stageChipW;
  s.addShape('roundRect', box({ x, y: G.chipY, w: G.stageChipW, h: G.chipH,
    fill: { color: C.base }, line: { color: accent, width: 1.75 },
    rectRadius: G.radiusPill, shadow: sh('chip') }));
  s.addText(stage, box({ x, y: G.chipY, w: G.stageChipW, h: G.chipH,
    fontFace: F.body, fontSize: S.chip, bold: true, charSpacing: 1.2,
    color: accent, align: 'center', valign: 'middle' }));
}

function deviceChip(s, device) {
  const d = T.device[device];
  if (!d) throw new Error(`Unknown device state: ${device}. Use 'NO TECH' or 'DEVICES'.`);
  const x = G.slideW - G.marginX - G.deviceChipW;
  s.addShape('roundRect', box({ x, y: G.chipY, w: G.deviceChipW, h: G.chipH,
    fill: { color: col(d.fill) }, line: { color: col(d.line), width: 1 },
    rectRadius: G.radiusPill, shadow: sh('chip') }));
  s.addText(device, box({ x, y: G.chipY, w: G.deviceChipW, h: G.chipH,
    fontFace: F.body, fontSize: S.chip, bold: true, charSpacing: 1.0,
    color: col(d.text), align: 'center', valign: 'middle' }));
}

/**
 * Create a content slide with its full chrome.
 * opts: { stage, device, title, subtitle }
 */
function slide(pres, opts) {
  const s = pres.addSlide();
  s.background = { color: C.base };
  stageChip(s, opts.stage);
  deviceChip(s, opts.device);
  if (opts.title) {
    s.addText(opts.title, box({ x: G.marginX, y: G.titleY, w: G.titleW, h: G.titleH,
      fontFace: F.display, fontSize: S.slideTitle, bold: true, color: C.ink, valign: 'middle' }));
  }
  if (opts.subtitle) {
    s.addText(opts.subtitle, box({ x: G.marginX, y: G.subtitleY, w: G.contentW, h: G.subtitleH,
      fontFace: F.body, fontSize: S.caption, color: C.muted, valign: 'middle' }));
  }
  s._cursor = opts.subtitle ? G.contentTop : G.contentTop - 0.20;
  return s;
}

/* ---------- cover ---------- */

/**
 * Cover. Soft-tinted outer frame, a pill eyebrow, a title that owns the upper
 * half, and one white panel carrying continuity (last lesson) and destination
 * (today's goal).
 * opts: { eyebrow, title, subtitle, lastLesson, todaysGoal }
 */
function cover(pres, opts) {
  const s = pres.addSlide();
  s.background = { color: C.base };

  s.addShape('roundRect', box({ x: G.marginX, y: 0.50, w: G.contentW, h: 6.50,
    fill: { color: C.surface }, line: { color: C.border, width: 2 },
    rectRadius: G.radiusCard, shadow: sh('card') }));

  const ix = G.marginX + 0.60, iw = G.contentW - 1.20;

  // pill eyebrow
  const ew = Math.min(iw, 0.15 * opts.eyebrow.length + 0.90);
  s.addShape('roundRect', box({ x: ix, y: 0.95, w: ew, h: 0.46,
    fill: { color: C.base }, line: { color: C.blue, width: 1.5 },
    rectRadius: G.radiusPill }));
  s.addText(opts.eyebrow, box({ x: ix, y: 0.95, w: ew, h: 0.46,
    fontFace: F.body, fontSize: S.caption, bold: true, color: C.blue,
    align: 'center', valign: 'middle' }));

  // bottom-anchored: a one-line title sits close to the subtitle, a two-line
  // title grows upward into the space instead of pushing everything down
  s.addText(opts.title, box({ x: ix, y: 1.55, w: iw, h: 1.60,
    fontFace: F.display, fontSize: S.coverTitle, bold: true, color: C.ink, valign: 'bottom' }));

  if (opts.subtitle) {
    s.addText(opts.subtitle, box({ x: ix, y: 3.28, w: iw, h: 0.55,
      fontFace: F.body, fontSize: S.bodySm, color: C.muted, valign: 'middle' }));
  }

  // white panel — last lesson + today's goal
  const py = 4.20, ph = 2.15;
  s.addShape('roundRect', box({ x: ix, y: py, w: iw, h: ph,
    fill: { color: C.base }, line: { color: C.border, width: 2 },
    rectRadius: G.radiusCard, shadow: sh('card') }));

  [['Last lesson', opts.lastLesson, C.surface, C.muted, false],
   ['Today\u2019s goal', opts.todaysGoal, C.blue, C.base, true]]
  .forEach(([label, value, chipFill, chipText, strong], i) => {
    const ry = py + 0.36 + i * 0.92;
    s.addShape('roundRect', box({ x: ix + 0.35, y: ry + 0.02, w: 1.75, h: 0.42,
      fill: { color: chipFill }, line: { color: chipFill }, rectRadius: G.radiusPill }));
    s.addText(label, box({ x: ix + 0.35, y: ry + 0.02, w: 1.75, h: 0.42,
      fontFace: F.body, fontSize: S.caption, bold: true, color: chipText,
      align: 'center', valign: 'middle' }));
    s.addText(value, box({ x: ix + 2.35, y: ry, w: iw - 2.75, h: 0.48,
      fontFace: F.body, fontSize: S.card, bold: strong, color: C.ink, valign: 'middle' }));
  });
  return s;
}

/* ---------- content components ---------- */

/** Full-width tinted band. kind: info | tip | note | extend | exit */
function callout(s, text, kind = 'info', y = null, h = 0.80) {
  const map = { info: 'blue', tip: 'green', note: 'amber', extend: 'purple', exit: 'red' };
  const tok = map[kind];
  if (!tok) throw new Error(`Unknown callout kind: ${kind}`);
  const top = y === null ? s._cursor : y;
  s.addShape('roundRect', box({ x: G.marginX, y: top, w: G.contentW, h,
    fill: { color: tint(tok) }, line: { color: C[tok], width: 2 },
    rectRadius: G.radiusCard, shadow: sh('card') }));
  s.addText(text, box({ x: G.marginX + 0.30, y: top, w: G.contentW - 0.60, h,
    fontFace: F.body, fontSize: S.bodySm, color: C.ink, valign: 'middle' }));
  s._cursor = top + h + G.gap;
  return s;
}

/** The "write this down" marker. Sits inline, amber. */
function copyBanner(s, text = 'Copy this into your notes', y = null) {
  const top = y === null ? s._cursor : y;
  const h = 0.42, w = 3.55;
  s.addShape('roundRect', box({ x: G.marginX, y: top, w, h,
    fill: { color: C.amberTint }, line: { color: C.amber, width: 2 },
    rectRadius: G.radiusCard, shadow: sh('card') }));
  s.addText('\u270E  ' + text, box({ x: G.marginX + 0.20, y: top, w: w - 0.40, h,
    fontFace: F.body, fontSize: S.caption, bold: true, color: C.ink, valign: 'middle' }));
  s._cursor = top + h + G.gap;
  return s;
}

/** Numbered rows. items: [{ head, body }] or [string] */
function numberedList(s, items, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const avail = G.contentBottom - top - (opts.reserve || 0);
  const h = Math.min(opts.rowH || 0.84, (avail - G.gap * (items.length - 1)) / items.length);
  items.forEach((it, i) => {
    const y = top + i * (h + G.gap);
    const head = typeof it === 'string' ? null : it.head;
    const body = typeof it === 'string' ? it : it.body;
    s.addShape('roundRect', box({ x: G.marginX, y, w: G.contentW, h,
      fill: { color: C.base }, line: { color: C.border }, rectRadius: G.radiusRow,
      shadow: sh('card') }));
    const d = 0.44, dy = y + (h - d) / 2;
    s.addShape('ellipse', box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fill: { color: C.blue }, line: { color: C.blue } }));
    s.addText(String(i + 1), box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fontFace: F.body, fontSize: S.caption, bold: true, color: C.base,
      align: 'center', valign: 'middle' }));
    const tx = G.marginX + 0.80, tw = G.contentW - 1.05;
    if (head) {
      s.addText([
        { text: head, options: { bold: true, breakLine: true } },
        { text: body, options: { fontSize: S.card, color: C.muted } }
      ], box({ x: tx, y, w: tw, h, fontFace: F.body, fontSize: S.bodySm, color: C.ink, valign: 'middle' }));
    } else {
      s.addText(body, box({ x: tx, y, w: tw, h,
        fontFace: F.body, fontSize: S.body, color: C.ink, valign: 'middle' }));
    }
  });
  s._cursor = top + items.length * (h + G.gap);
  return s;
}

/** Lettered rows (A/B/C) — for sorting and spot-the-error warm-ups. */
function letteredList(s, items, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const avail = G.contentBottom - top - (opts.reserve || 0);
  const h = Math.min(opts.rowH || 0.72, (avail - G.gap * (items.length - 1)) / items.length);
  items.forEach((text, i) => {
    const y = top + i * (h + G.gap);
    s.addShape('roundRect', box({ x: G.marginX, y, w: G.contentW, h,
      fill: { color: C.base }, line: { color: C.border }, rectRadius: G.radiusRow,
      shadow: sh('card') }));
    const d = 0.42, dy = y + (h - d) / 2;
    s.addShape('roundRect', box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fill: { color: C.blue }, line: { color: C.blue }, rectRadius: 0.10 }));
    s.addText(String.fromCharCode(65 + i), box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fontFace: F.body, fontSize: S.caption, bold: true, color: C.base,
      align: 'center', valign: 'middle' }));
    s.addText(text, box({ x: G.marginX + 0.80, y, w: G.contentW - 1.05, h,
      fontFace: F.body, fontSize: S.body, color: C.ink, valign: 'middle' }));
  });
  s._cursor = top + items.length * (h + G.gap);
  return s;
}

/** Three tier cards. Each: { primary, secondary }. Colour comes from the tier, always. */
function tierCards(s, f, d, e, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const h = opts.h || 3.30;
  const w = (G.contentW - G.gap * 2) / 3;
  [['Foundation', f, 'foundation'], ['Developing', d, 'developing'], ['Extending', e, 'extending']]
    .forEach(([label, content, tier], i) => {
      const tok = tierToken(tier);
      const x = G.marginX + i * (w + G.gap);
      s.addShape('roundRect', box({ x, y: top, w, h,
        fill: { color: tint(tok) }, line: { color: C[tok], width: 2 },
        rectRadius: G.radiusCard, shadow: sh('card') }));
      const lw = 1.85, lh = 0.40;
      s.addShape('roundRect', box({ x: x + 0.28, y: top + 0.26, w: lw, h: lh,
        fill: { color: C[tok] }, line: { color: C[tok] }, rectRadius: G.radiusPill,
        shadow: sh('chip') }));
      s.addText(label, box({ x: x + 0.28, y: top + 0.26, w: lw, h: lh,
        fontFace: F.body, fontSize: S.caption, bold: true,
        color: C.base, align: 'center', valign: 'middle' }));
      const pTop = top + 0.86;
      const divY = content.secondary ? top + h - 1.05 : top + h - 0.20;
      s.addText(content.primary, box({ x: x + 0.28, y: pTop, w: w - 0.56,
        h: Math.max(0.50, divY - pTop - 0.10),
        fontFace: F.body, fontSize: S.card, color: C.ink, valign: 'top' }));
      if (content.secondary) {
        s.addShape('line', box({ x: x + 0.28, y: divY, w: w - 0.56, h: 0,
          line: { color: C[tok], width: 1 } }));
        s.addText(content.secondary, box({ x: x + 0.28, y: divY + 0.10, w: w - 0.56, h: 0.82,
          fontFace: F.body, fontSize: S.card, color: C.muted, valign: 'top' }));
      }
    });
  s._cursor = top + h + G.gap;
  return s;
}

/** Data table. headers: [string], rows: [[string]], colW: [inches] optional */
function dataTable(s, headers, rows, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const colW = opts.colW || headers.map(() => G.contentW / headers.length);
  s.addTable([
    headers.map(h => ({ text: h, options: {
      bold: true, color: C.muted, fill: { color: C.surface }, fontSize: S.caption } })),
    ...rows.map(r => r.map(c => ({ text: c, options: { color: C.ink, fontSize: S.card } })))
  ], {
    x: G.marginX, y: top, w: G.contentW, colW,
    border: { type: 'solid', color: C.border, pt: 1 },
    fontFace: F.body, valign: 'top', autoPage: false,
    margin: 0.08
  });
  s._cursor = top + 0.42 + rows.length * (opts.rowH || 0.52);
  return s;
}

/** Before/after or wrong/right pair. */
function comparePair(s, left, right, opts = {}) {
  const top = opts.y === null || opts.y === undefined ? s._cursor : opts.y;
  const h = opts.h || 2.10;
  const w = (G.contentW - G.gap) / 2;
  [[left, 'red', G.marginX], [right, 'green', G.marginX + w + G.gap]].forEach(([side, tok, x]) => {
    s.addShape('roundRect', box({ x, y: top, w, h,
      fill: { color: tint(tok) }, line: { color: C[tok], width: 2 },
      rectRadius: G.radiusCard, shadow: sh('card') }));
    s.addText(side.label, box({ x: x + 0.25, y: top + 0.18, w: w - 0.50, h: 0.34,
      fontFace: F.body, fontSize: S.caption, bold: true, charSpacing: 1.0, color: C[tok], valign: 'middle' }));
    s.addText(side.text, box({ x: x + 0.25, y: top + 0.60, w: w - 0.50, h: h - 0.85,
      fontFace: F.body, fontSize: S.bodySm, color: C.ink, valign: 'top' }));
  });
  s._cursor = top + h + G.gap;
  return s;
}

/** Workbook — the one slide where devices come out. */
function workbookSlide(pres, opts) {
  const s = slide(pres, {
    stage: 'APPLYING', device: 'DEVICES',
    title: opts.title || 'Workbook',
    subtitle: `${opts.file} \u00B7 ${opts.minutes} minutes`
  });
  panel(s, {
    kind: 'tip',
    heading: 'Over to you \u2014 grab your device and open today\u2019s workbook.',
    body: opts.instruction ||
      'Log in, open the workbook for this lesson, and make a start from the top. '
      + 'Keep your notes open beside you \u2014 you\u2019ll want them. Work down in order, '
      + 'and give each one a go before you ask. Getting stuck is part of it; '
      + 'staying stuck quietly isn\u2019t.',
    y: G.contentTop, h: 2.35
  });
  if (opts.tasks) numberedList(s, opts.tasks);
  return s;
}

/** Exit ticket. questions: [string] */
function exitTicket(pres, opts) {
  const s = slide(pres, {
    stage: 'EXIT', device: opts.device || 'DEVICES',
    title: 'Exit ticket',
    subtitle: `${opts.location} \u00B7 ${opts.minutes} minutes \u00B7 no notes`
  });
  numberedList(s, opts.questions, { rowH: 0.78 });
  callout(s, opts.closing || 'Submit before you pack up.', 'exit', G.contentBottom - 0.80);
  return s;
}

/** Brain break. */
function brainBreak(pres, opts = {}) {
  const s = slide(pres, { stage: 'BREAK', device: 'NO TECH',
    title: opts.title || 'Take a breather' });
  s.addShape('roundRect', box({ x: G.marginX, y: 2.10, w: G.contentW, h: 2.60,
    fill: { color: C.blueTint }, line: { color: C.blue, width: 2.5 },
    rectRadius: 0.16, shadow: sh('card') }));
  s.addText(opts.text || 'Pens down, screens off. Your teacher will tell you what today\u2019s break is.',
    box({ x: G.marginX + 0.60, y: 3.00, w: G.contentW - 1.20, h: 0.80,
      fontFace: F.display, fontSize: S.lead, bold: true, color: C.ink,
      align: 'center', valign: 'middle' }));
  return s;
}

/**
 * Open panel. The escape hatch for slides whose structure genuinely varies by
 * lesson — warm ups, key concepts, worked examples. Gives you a framed, raised
 * area with an optional heading and free body text, so a lesson can shape the
 * content without inventing new geometry.
 * opts: { heading, body, kind, y, h }   kind: neutral | info | tip | note | extend
 */
function panel(s, opts = {}) {
  const map = { neutral: null, info: 'blue', tip: 'green', note: 'amber', extend: 'purple' };
  const tok = map[opts.kind || 'neutral'];
  const top = opts.y === undefined || opts.y === null ? s._cursor : opts.y;
  const h = opts.h || (G.contentBottom - top);
  s.addShape('roundRect', box({ x: G.marginX, y: top, w: G.contentW, h,
    fill: { color: tok ? tint(tok) : C.surface },
    line: { color: tok ? C[tok] : C.border, width: tok ? 2 : 1.5 },
    rectRadius: G.radiusCard, shadow: sh('card') }));
  let ty = top + 0.30;
  if (opts.heading) {
    s.addText(opts.heading, box({ x: G.marginX + 0.35, y: ty, w: G.contentW - 0.70, h: 0.42,
      fontFace: F.display, fontSize: S.lead, bold: true, color: C.ink, valign: 'middle' }));
    ty += 0.55;
  }
  if (opts.body) {
    s.addText(opts.body, box({ x: G.marginX + 0.35, y: ty, w: G.contentW - 0.70,
      h: top + h - ty - 0.28,
      fontFace: F.body, fontSize: S.bodySm, color: C.ink,
      lineSpacingMultiple: 1.25, valign: 'top' }));
  }
  s._cursor = top + h + G.gap;
  return s;
}

/**
 * Question rows with their answers revealed — the retrieval follow-up slide.
 * items: [{ q, a }]
 */
function answerList(s, items, opts = {}) {
  const top = opts.y === undefined || opts.y === null ? s._cursor : opts.y;
  const avail = G.contentBottom - top - (opts.reserve || 0);
  const h = Math.min(opts.rowH || 1.05, (avail - G.gap * (items.length - 1)) / items.length);
  items.forEach((it, i) => {
    const y = top + i * (h + G.gap);
    s.addShape('roundRect', box({ x: G.marginX, y, w: G.contentW, h,
      fill: { color: C.greenTint }, line: { color: C.green, width: 2 },
      rectRadius: G.radiusRow, shadow: sh('card') }));
    const d = 0.44, dy = y + (h - d) / 2;
    s.addShape('ellipse', box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fill: { color: C.green }, line: { color: C.green } }));
    s.addText(String(i + 1), box({ x: G.marginX + 0.18, y: dy, w: d, h: d,
      fontFace: F.body, fontSize: S.caption, bold: true, color: C.base,
      align: 'center', valign: 'middle' }));
    s.addText([
      { text: it.q, options: { color: C.muted, breakLine: true } },
      { text: it.a, options: { bold: true, color: C.ink } }
    ], box({ x: G.marginX + 0.80, y, w: G.contentW - 1.05, h,
      fontFace: F.body, fontSize: S.card, valign: 'middle' }));
  });
  s._cursor = top + items.length * (h + G.gap);
  return s;
}

/** In-slide heading, for splitting a slide into two labelled halves. */
function sectionHeading(s, text, y = null) {
  const top = y === null ? s._cursor : y;
  s.addText(text, box({ x: G.marginX, y: top, w: G.contentW, h: 0.40,
    fontFace: F.display, fontSize: S.lead, bold: true, color: C.ink, valign: 'middle' }));
  s._cursor = top + 0.40 + G.gap;
  return s;
}

/** Height a callout occupies — pass as `reserve` when one follows a list. */
const CALLOUT_H = 1.14;

/** Footer note, pinned to the baseline. */
function footer(s, text) {
  s.addText(text, box({ x: G.marginX, y: G.footerY, w: G.contentW, h: G.footerH,
    fontFace: F.body, fontSize: S.caption, color: C.muted, valign: 'middle' }));
  return s;
}

/** Speaker notes — required on every slide. */
function notes(s, text) { s.addNotes(text); return s; }

module.exports = {
  tokens: T, newDeck, cover, slide, stageChip, deviceChip,
  callout, copyBanner, numberedList, letteredList, tierCards, dataTable,
  comparePair, workbookSlide, exitTicket, brainBreak, panel, answerList,
  sectionHeading, footer, notes, CALLOUT_H
};
