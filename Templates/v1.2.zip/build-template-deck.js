/* Golden reference deck.
   Copy this file to start a lesson and replace the CONTENT only.

   Slides fall into two kinds:
     FIXED    — same shape every lesson (cover, objective, retrieval, brain
                break, workbook, reflection, exit, next steps). Keep the shape.
     VARIABLE — shape depends on the concept being taught (warm up, key
                concept, worked example, discussion, common mistakes). These
                use C.panel(), which gives you a framed area to fill however
                the content needs. Repeat the key-concept → worked-example
                pair as many times as the lesson has concepts; drop the
                discussion and common-mistakes slides when they don't apply. */

const C = require('./assets/deck-components.js');
const G = C.tokens.geometry;

(async () => {
  const pres = C.newDeck({ title: 'EduPortal lesson template' });

  /* 1 — COVER (fixed) */
  C.notes(C.cover(pres, {
    eyebrow: 'UNIT [N] \u00B7 [AREA OF STUDY] \u00B7 [SUBJECT] \u00B7 LESSON [N]',
    title: 'Lesson title goes here',
    subtitle: 'Sub-idea one \u00B7 Sub-idea two \u00B7 Sub-idea three',
    lastLesson: '[Prior topic \u2014 one line]',
    todaysGoal: '[The learning objective, verbatim]'
  }), 'Cover. Do not read it aloud — students are settling. Have this up as they come in so the continuity line does the work before you start talking.');

  /* 2 — WARM UP (variable) */
  let s = C.slide(pres, {
    stage: 'WARM UP', device: 'NO TECH',
    title: 'Warm up',
    subtitle: '5 minutes \u00B7 notebooks only'
  });
  C.panel(s, {
    kind: 'info',
    heading: 'Purpose',
    body: 'To settle the room and bring back what you already know.\n\n'
        + 'This warm up recalls the prior knowledge and skills today builds on. '
        + 'Start it the moment you sit down \u2014 no waiting to be told.\n\n'
        + '[Replace this panel with the actual warm-up task. Its shape depends '
        + 'entirely on the lesson: a sort, a spot-the-error, a quick calculation, '
        + 'a definition recall.]',
    y: G.contentTop
  });
  C.notes(s, 'Timing: 5 min. Do not resolve it — the answer comes out of the explicit teaching. Circulate and note who is reasoning rather than guessing; call on those first.');

  /* 3 — LEARNING OBJECTIVE (fixed) */
  s = C.slide(pres, { stage: 'OBJECTIVE', device: 'NO TECH', title: 'Learning objective' });
  C.callout(s, 'To be able to [verb] [object] [condition] \u2014 concise, one sentence, copyable.',
    'info', 1.25, 1.55);
  C.sectionHeading(s, 'Success criteria', 3.05);
  C.tierCards(s,
    { primary: 'I can [recall or explain the core idea].' },
    { primary: 'I can [produce the thing] for a given context.' },
    { primary: 'I can [evaluate or critique] a worked set.' },
    { y: 3.60, h: 2.55 });
  C.footer(s, 'You will check yourself against these criteria in the reflection.');
  C.notes(s, 'Read the objective aloud once, then have students copy it. Point at the tier they are aiming for. Return to this slide in the reflection.');

  /* 4 — RETRIEVAL (fixed) */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: 'Retrieval \u2014 [last lesson\u2019s topic]',
    subtitle: 'Cold call \u00B7 no notes \u00B7 3 minutes'
  });
  C.numberedList(s, [
    'Retrieval question one.',
    'Retrieval question two.',
    'Retrieval question three.',
    'Retrieval question four.'
  ]);
  C.notes(s, 'Cold call, no hands. Give thinking time before naming anyone. Do not reveal answers yet — the next slide does that.');

  /* 5 — RETRIEVAL ANSWERS (fixed) */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: 'Retrieval \u2014 answers',
    subtitle: 'Mark your own \u00B7 correct anything you missed'
  });
  C.answerList(s, [
    { q: 'Retrieval question one.', a: 'The answer, stated the way you want it said back to you.' },
    { q: 'Retrieval question two.', a: 'The answer.' },
    { q: 'Retrieval question three.', a: 'The answer.' },
    { q: 'Retrieval question four.', a: 'The answer.' }
  ]);
  C.notes(s, 'Students self-mark. If more than a third missed the same item, reteach it in 60 seconds now rather than pushing on — today builds directly on this.');

  /* 6 — KEY CONCEPT (variable; repeat this pair per concept) */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: '[Key concept]',
    subtitle: 'Concept [n] of [total]'
  });
  C.copyBanner(s);
  C.panel(s, {
    heading: '[The concept, stated in one line]',
    body: '[Replace this panel with the explicit teaching for this concept. '
        + 'Structure varies: a definition and its parts, a short list of reasons, '
        + 'a rule with its exceptions, a labelled diagram, a comparison.]\n\n'
        + '[Duplicate this slide and the worked example that follows it once per '
        + 'concept. A lesson may have one concept or five.]'
  });
  C.notes(s, 'Copy-down slide. Give silent writing time and do not talk over it. Repeat this slide per concept — one concept per slide, never two.');

  /* 7 — WORKED EXAMPLE (variable; always follows a key concept) */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: 'Worked example',
    subtitle: '[concept] \u00B7 model the method once, out loud'
  });
  C.panel(s, {
    heading: '[The example]',
    body: '[Replace with the worked example for the concept above. Its shape '
        + 'follows the concept: a wrong-then-right pair, a step-by-step '
        + 'derivation, an annotated artefact, a decision walked through.]\n\n'
        + '[C.comparePair() gives you a two-column wrong/right layout if that '
        + 'is the right shape; C.dataTable() gives you a parts-and-jobs table.]'
  });
  C.notes(s, 'Think aloud. Narrate the decisions, not just the steps — the reasoning is the teaching. Always pair this with the concept slide before it.');

  /* 8 — DISCUSSION (variable; include only where a concept benefits from it) */
  s = C.slide(pres, {
    stage: 'LEARNING', device: 'NO TECH',
    title: 'Discussion \u2014 [tension to surface]',
    subtitle: '8 minutes \u00B7 groups of three'
  });
  C.panel(s, {
    kind: 'info',
    heading: '[The question with no single right answer]',
    body: '[Include this slide only for concepts where a short class discussion '
        + 'genuinely adds something \u2014 a trade-off, a judgement call, a case '
        + 'where practitioners disagree. Drop it otherwise.]',
    h: 2.40
  });
  C.callout(s, 'Extending: argue the opposite case and say what it would cost.', 'extend');
  C.notes(s, 'Groups of three, 8 min. Take two contrasting responses only — a full round of the room eats the workbook time. Omit this slide if the concept has no real tension in it.');

  /* 9 — BRAIN BREAK (fixed) */
  C.notes(C.brainBreak(pres), 'Genuine break. Announce today\u2019s break activity yourself. Do not use the time to set up the next segment. Two minutes, timed.');

  /* 10 — COMMON MISTAKES (variable; only where misconceptions exist) */
  s = C.slide(pres, {
    stage: 'REFLECTING', device: 'NO TECH',
    title: 'Common mistakes',
    subtitle: 'Check your own work against each'
  });
  C.numberedList(s, [
    { head: '[Mistake one]', body: 'What it looks like, and the one-line correction.' },
    { head: '[Mistake two]', body: 'What it looks like, and the one-line correction.' },
    { head: '[Mistake three]', body: 'What it looks like, and the one-line correction.' }
  ], { rowH: 1.10 });
  C.notes(s, 'Only include this slide for concepts that have known misconceptions. These should be errors that actually appear in student work, not hypothetical ones.');

  /* 11 — WORKBOOK (fixed) */
  C.notes(C.workbookSlide(pres, {
    file: 'L[N]_[ShortTitle]_workbook.html',
    minutes: 30,
    tasks: [
      { head: 'Work down in order', body: 'Foundation sections first \u2014 they are auto-marked, so you get feedback straight away.' },
      { head: 'Then the written sections', body: 'Saved as you type. Use your notes.' },
      { head: 'Extending, if you get there', body: 'Attempt it only once everything above is complete.' }
    ]
  }), 'The only slide where devices come out. Do the gate explicitly: lids stay shut until this slide is up. Circulate rather than sitting at the desk — 30 minutes.');

  /* 12 — REFLECTION (fixed) */
  s = C.slide(pres, {
    stage: 'REFLECTING', device: 'DEVICES',
    title: 'Reflection',
    subtitle: '5 minutes before the exit ticket'
  });
  C.panel(s, {
    kind: 'info',
    body: '1.   What\u2019s one thing you already knew about?\n\n'
        + '2.   What\u2019s something new you learned today?',
    y: G.contentTop, h: 1.70
  });
  C.sectionHeading(s, 'Success criteria \u2014 what success looks like', 3.35);
  C.tierCards(s,
    { primary: 'I can [recall or explain the core idea].',
      secondary: 'Success looks like: [a concrete met response].' },
    { primary: 'I can [produce the thing] for a given context.',
      secondary: 'Success looks like: [a concrete met response].' },
    { primary: 'I can [evaluate or critique] a worked set.',
      secondary: 'Success looks like: [a concrete met response].' },
    { y: 3.90, h: 2.60 });
  C.notes(s, 'Formative, not graded. Take a couple of responses to the two questions aloud, then have students self-rate against the tier they aimed for on the objective slide.');

  /* 13 — EXIT TICKET (fixed) */
  C.notes(C.exitTicket(pres, {
    location: 'Workbook \u2014 exit ticket section',
    minutes: 5,
    device: 'DEVICES',
    questions: [
      '[Question drawn from any concept covered today.]',
      '[Question drawn from any concept covered today.]',
      '[Question drawn from any concept covered today.]'
    ],
    closing: 'Submit before you pack up. No notes.'
  }), 'Five minutes, notes closed. Pick three questions spanning the concepts taught — no fixed format, and not always one per tier. Submission writes the progress status; students who do not submit show as in-progress.');

  /* 14 — NEXT STEPS (fixed) */
  s = C.slide(pres, { stage: 'NEXT STEPS', device: 'DEVICES', title: 'Next steps' });
  C.numberedList(s, [
    { head: 'Next lesson \u2014 L[N+1]: [title]', body: 'One line on what it covers and how it follows from today.' },
    { head: 'Assessment progress', body: 'Where you should be on the unit assessment by now.' },
    { head: 'Homework', body: 'What to finish, and by when (YYYY-MM-DD).' },
    { head: 'Stuck?', body: 'Unit site for full notes; ask before the next lesson, not during it.' }
  ], { y: G.contentTop, rowH: 1.15 });
  C.notes(s, 'Say the due date aloud and have students write it. Point at the unit site link — it is the reference; the workbook is not.');

  await pres.writeFile({ fileName: 'TEMPLATE_lesson.pptx' });
  console.log('wrote TEMPLATE_lesson.pptx');
})();
