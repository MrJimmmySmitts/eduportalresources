#!/usr/bin/env python3
"""
EduPortal template conformance checker.

    python3 validate.py L7_Thing.pptx L7_Thing_workbook.html

Checks a generated lesson file against tokens.json. This is the drift-catcher:
the Production Checklist is a prose reminder, this is an actual gate. Run it
before presenting any lesson files.

Exit code 0 = conformant, 1 = violations found.
"""
import json, re, sys, zipfile, pathlib

HERE = pathlib.Path(__file__).parent
T = json.loads((HERE / "tokens.json").read_text())

C = T["colour"]
ALLOWED_HEX = {v.upper() for k, v in C.items() if not k.startswith("_")}
ALLOWED_FONTS = set(T["font"]["deck"].values())
ALLOWED_PT = {float(v) for k, v in T["typeScale"].items() if not k.startswith("_")}
G = T["geometry"]
EMU = 914400

problems = []
notes = []


def fail(f, msg):
    problems.append(f"{f}: {msg}")


# ----------------------------------------------------------------- PPTX
def check_pptx(path):
    f = pathlib.Path(path).name
    try:
        z = zipfile.ZipFile(path)
    except Exception as e:
        return fail(f, f"cannot open: {e}")

    slides = sorted(
        [n for n in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)],
        key=lambda n: int(re.search(r"\d+", n.split("/")[-1]).group()),
    )
    if not slides:
        return fail(f, "no slides found")

    pres = z.read("ppt/presentation.xml").decode("utf8", "ignore")
    m = re.search(r'sldSz[^>]*cx="(\d+)"[^>]*cy="(\d+)"', pres)
    if m:
        w, h = int(m[1]) / EMU, int(m[2]) / EMU
        if abs(w - G["slideW"]) > 0.02 or abs(h - G["slideH"]) > 0.02:
            fail(f, f"slide size {w:.2f}x{h:.2f}in — expected "
                    f"{G['slideW']}x{G['slideH']} (set pres.layout='LAYOUT_WIDE' BEFORE adding slides)")

    for s in slides:
        n = re.search(r"\d+", s.split("/")[-1]).group()
        xml = z.read(s).decode("utf8", "ignore")

        for hexv in set(re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', xml)):
            if hexv.upper() not in ALLOWED_HEX:
                fail(f, f"slide {n}: colour #{hexv.upper()} is not a token "
                        f"— add it to tokens.json or use an existing one")

        for font in set(re.findall(r'typeface="([^"]+)"', xml)):
            if font.startswith("+") or font in ("Arial",):
                continue
            if font not in ALLOWED_FONTS:
                fail(f, f"slide {n}: font '{font}' is outside the stack "
                        f"({', '.join(sorted(ALLOWED_FONTS))})")

        for sz in set(re.findall(r'\ssz="(\d+)"', xml)):
            pt = int(sz) / 100
            if pt not in ALLOWED_PT:
                fail(f, f"slide {n}: {pt}pt is outside the type scale "
                        f"({', '.join(str(int(x)) for x in sorted(ALLOWED_PT))})")

        # Off-canvas check, per shape. Decorative blobs are exempt: they are
        # translucent (an <a:alpha> element) and are meant to bleed off the edge.
        # Anything opaque that runs off the canvas is a real defect.
        for sp in re.findall(r"<p:sp>.*?</p:sp>", xml, re.S):
            if "<a:alpha " in sp:
                continue
            m2 = re.search(r'<a:off x="(-?\d+)" y="(-?\d+)"\s*/>\s*'
                           r'<a:ext cx="(\d+)" cy="(\d+)"\s*/>', sp)
            if not m2:
                continue
            x, y, cx, cy = (int(v) for v in m2.groups())
            r, b = (x + cx) / EMU, (y + cy) / EMU
            if r > G["slideW"] + 0.02 or b > G["slideH"] + 0.02:
                fail(f, f"slide {n}: an opaque shape ends at ({r:.2f}, {b:.2f})in "
                        f"— off the {G['slideW']}x{G['slideH']} canvas")

        rel = f"ppt/slides/_rels/slide{n}.xml.rels"
        has_notes = rel in z.namelist() and "notesSlide" in z.read(rel).decode("utf8", "ignore")
        if not has_notes:
            fail(f, f"slide {n}: no speaker notes")

    dates = re.findall(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b", " ".join(
        z.read(s).decode("utf8", "ignore") for s in slides))
    for d in set(dates):
        fail(f, f"date '{d}' is not ISO 8601 (YYYY-MM-DD)")

    notes.append(f"{f}: {len(slides)} slides checked")


# ----------------------------------------------------------------- HTML
def check_html(path):
    f = pathlib.Path(path).name
    src = pathlib.Path(path).read_text(encoding="utf8", errors="ignore")
    is_site = "_site" in f

    css = (HERE / "eduportal.css").read_text()
    root = re.search(r":root\{(.*?)\}", css, re.S)
    if root and root.group(1).strip() not in src:
        fail(f, "the :root token block does not match assets/eduportal.css verbatim "
                "— inline the shared stylesheet rather than hand-writing it")

    for hexv in set(re.findall(r"#([0-9A-Fa-f]{6})\b", src)):
        if hexv.upper() not in ALLOWED_HEX and hexv.upper() != "FFFFFF":
            fail(f, f"colour #{hexv.upper()} is not a token")

    # strip line comments so explanatory prose about banned values doesn't self-trigger
    scan = re.sub(r"^\s*(//|/\*|\*).*$", "", src, flags=re.M)
    for banned in T["storage"]["banned"]:
        if banned == "done":
            if re.search(r"""['"]done['"]""", scan):
                fail(f, "status value 'done' is banned — use in-progress | submitted | marked")
        elif banned in scan:
            fail(f, f"banned identifier '{banned}' present")

    if re.search(r"dd\s*/\s*mm\s*/\s*yyyy", src, re.I):
        fail(f, "date placeholder is not ISO 8601 — use YYYY-MM-DD")
    if "toLocaleDateString" in src:
        fail(f, "toLocaleDateString produces a non-ISO date — use toISOString().slice(0,10)")

    if is_site:
        for bad, why in [("DataService", "the unit site must not track progress"),
                         ("localStorage", "the unit site must not touch storage"),
                         ("<textarea", "the unit site is read-only"),
                         ("<input", "the unit site is read-only"),
                         ('id="fill"', "the unit site has no progress bar")]:
            if bad in src:
                fail(f, f"'{bad}' found — {why}")
    else:
        for need, why in [("DataService", "the workbook must implement the DataService layer"),
                          ("_syncProgress", "the workbook must sync progress"),
                          ("_site.html#", "the workbook must deep-link to its unit-site section")]:
            if need not in src:
                fail(f, f"missing '{need}' — {why}")
        for bad, why in [("Save Marking", "no teacher marking panel in the workbook"),
                         ("Feedback</", "no teacher marking panel in the workbook")]:
            if bad in src:
                fail(f, f"'{bad}' found — {why}")

        tiers = {t for t in ("t-f", "t-d", "t-e") if t in src}
        if len(tiers) < 3:
            fail(f, f"only {len(tiers)}/3 differentiation tiers present "
                    f"— every lesson needs Foundation, Developing and Extending")

        fields = len(re.findall(r"<textarea|<select|input type=\"text\"", src))
        if fields < 20:
            notes.append(f"{f}: only {fields} input fields — under-provisioned for a "
                         f"double period if this is a skills-based subject")

    if "🔵" in src:
        fail(f, "Extending tier uses 🟣, not 🔵")

    notes.append(f"{f}: checked")


# ----------------------------------------------------------------- main
def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    for p in argv[1:]:
        if p.endswith(".pptx"):
            check_pptx(p)
        elif p.endswith(".html"):
            check_html(p)
        else:
            print(f"skipping {p} (not .pptx or .html)")

    for n in notes:
        print(f"  · {n}")
    if problems:
        print(f"\n{len(problems)} conformance problem(s):\n")
        for p in problems:
            print(f"  ✗ {p}")
        print("\nFix these in the generator, not by hand-editing the output.")
        return 1
    print("\n✓ conformant with tokens.json")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
